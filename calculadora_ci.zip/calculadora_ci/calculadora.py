import requests
from flask import Flask, render_template, request

def calcular():
    num1 = float(request.form['num1'])
    num2 = float(request.form['num2'])
    operacao = request.form['operacao']

    if operacao == '+':
        resultado = num1 + num2
        etapas = f'{num1} + {num2} = {resultado}'
    elif operacao == '-':
        resultado = num1 - num2
        etapas = f'{num1} - {num2} = {resultado}'
    elif operacao == '*':
        resultado = num1 * num2
        etapas = f'{num1} * {num2} = {resultado}'
    elif operacao == '/':
        if num2 != 0:
            resultado = num1 / num2
            etapas = f'{num1} / {num2} = {resultado}'
        else: 
            resultado = 'Erro. Não é possivel dividir por 0'
            etapas = 'Não é possivel dividir por 0'
    elif operacao == 'dx/dy':
        resultado = num2 * num1 ** num2 - 1
        etapas = f'Dx/Dy {num1} ** {num2} = {resultado}'
    else:
        resultado = 'Operação inválida'
        etapas = 'A operação selecionada é invalida'
    return render_template('index.html', etapas=etapas, resultados=resultado)




    
