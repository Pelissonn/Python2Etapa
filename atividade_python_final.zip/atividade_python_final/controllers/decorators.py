from functools import wraps
from flask import session, redirect, url_for, flash


def login_required(f):
    """Protege rotas internas exigindo sessão ativa (usuario_id na session)."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if 'usuario_id' not in session:
            flash('Você precisa estar logado para acessar essa página.', 'warning')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return wrapper
