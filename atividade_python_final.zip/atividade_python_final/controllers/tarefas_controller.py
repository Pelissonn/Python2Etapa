import requests
from flask import Blueprint, render_template, request, session, redirect, url_for, flash
from sqlalchemy import func
from models.models import db, Tarefa
from controllers.decorators import login_required

tarefas_bp = Blueprint('tarefas', __name__)


@tarefas_bp.route('/dashboard')
@login_required
def dashboard():
    tarefas = Tarefa.query.filter_by(usuario_id=session['usuario_id']).all()

    try:
        resposta = requests.get('https://api.adviceslip.com/advice', timeout=5)
        frase = resposta.json()['slip']['advice']
    except Exception:
        frase = 'Não foi possível carregar a frase do dia.'

    return render_template('dashboard.html', tarefas=tarefas, frase=frase)


@tarefas_bp.route('/nova_tarefa', methods=['GET', 'POST'])
@login_required
def nova_tarefa():
    if request.method == 'POST':
        titulo = str(request.form['titulo'])
        descricao = str(request.form.get('descricao', ''))

        if not titulo.strip():
            flash('O título é obrigatório.', 'danger')
            return redirect(url_for('tarefas.nova_tarefa'))

        tarefa = Tarefa(titulo=titulo, descricao=descricao, usuario_id=session['usuario_id'])
        db.session.add(tarefa)
        db.session.commit()

        flash('Tarefa criada com sucesso!', 'success')
        return redirect(url_for('tarefas.dashboard'))

    return render_template('nova_tarefa.html')


@tarefas_bp.route('/editar/<int:id>', methods=['GET', 'POST'])
@login_required
def editar_tarefa(id):
    tarefa = Tarefa.query.filter_by(id=id, usuario_id=session['usuario_id']).first()

    if not tarefa:
        flash('Tarefa não encontrada.', 'danger')
        return redirect(url_for('tarefas.dashboard'))

    if request.method == 'POST':
        tarefa.titulo = str(request.form['titulo'])
        tarefa.descricao = str(request.form.get('descricao', ''))
        tarefa.status = str(request.form['status'])
        db.session.commit()

        flash('Tarefa atualizada com sucesso!', 'success')
        return redirect(url_for('tarefas.dashboard'))

    return render_template('editar_tarefa.html', tarefa=tarefa)


@tarefas_bp.route('/excluir/<int:id>')
@login_required
def excluir_tarefa(id):
    tarefa = Tarefa.query.filter_by(id=id, usuario_id=session['usuario_id']).first()

    if tarefa:
        db.session.delete(tarefa)
        db.session.commit()
        flash('Tarefa excluída com sucesso!', 'success')
    else:
        flash('Tarefa não encontrada.', 'danger')

    return redirect(url_for('tarefas.dashboard'))

@tarefas_bp.route('/tarefas/filtrar')
@login_required
def filtrar_tarefas():
    status = request.args.get('status', 'todas')

    query = Tarefa.query.filter_by(usuario_id=session['usuario_id'])
    if status != 'todas':
        query = query.filter_by(status=status)

    tarefas = query.all()

    resultado = [
        {
            'id': t.id,
            'titulo': t.titulo,
            'descricao': t.descricao,
            'status': t.status
        }
        for t in tarefas
    ]
    return {'tarefas': resultado}

@tarefas_bp.route('/api/progresso')
@login_required
def progresso_json():
    resultado = (
        db.session.query(Tarefa.status, func.count(Tarefa.id))
        .filter_by(usuario_id=session['usuario_id'])
        .group_by(Tarefa.status)
        .all()
    )

    dados = {'pendente': 0, 'em_andamento': 0, 'concluida': 0}
    for status, quantidade in resultado:
        dados[status] = quantidade

    return dados

@tarefas_bp.route('/dashboard/progresso')
@login_required
def progresso_pagina():
    return render_template('progresso.html')
