from flask import Flask
from models.models import db

app = Flask(
    __name__,
    template_folder='views/templates',
    static_folder='views/static'
)

app.config['SECRET_KEY'] = 'cotemig'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///banco.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

with app.app_context():
    db.create_all()

# --------------------------------------------- Registro dos Blueprints --------------------------------------------
from controllers.auth_controller import auth_bp
from controllers.tarefas_controller import tarefas_bp

app.register_blueprint(auth_bp)
app.register_blueprint(tarefas_bp)


# -----------------------------------------------------------------------------------------

if __name__ == '__main__':
    app.run(debug=True)
