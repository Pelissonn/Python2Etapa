function alternarModoEscuro() {
    document.body.classList.toggle('modo-escuro');
    const ativo = document.body.classList.contains('modo-escuro');
    localStorage.setItem('modoEscuro', ativo);
}

document.addEventListener('DOMContentLoaded', function () {
    const preferencia = localStorage.getItem('modoEscuro');
    if (preferencia === 'true') {
        document.body.classList.add('modo-escuro');
    }
});

function corDoStatus(status) {
    if (status === 'pendente') return 'card-pendente';
    if (status === 'em_andamento') return 'card-andamento';
    if (status === 'concluida') return 'card-concluida';
    return '';
}

function renderizarTarefas(tarefas) {
    const container = document.getElementById('lista-tarefas');
    container.innerHTML = '';

    if (tarefas.length === 0) {
        container.innerHTML = '<p>Nenhuma tarefa encontrada.</p>';
        return;
    }

    tarefas.forEach(function (tarefa) {
        const div = document.createElement('div');
        div.className = 'card-tarefa ' + corDoStatus(tarefa.status);
        div.innerHTML = `
            <strong>${tarefa.titulo}</strong> — ${tarefa.status}
            <br>${tarefa.descricao}
            <br>
            <a href="/editar/${tarefa.id}">Editar</a>
            <a href="/excluir/${tarefa.id}">Excluir</a>
        `;
        container.appendChild(div);
    });
}

function filtrarTarefas() {
    const status = document.getElementById('filtro-status').value;

    fetch(`/tarefas/filtrar?status=${status}`)
        .then(function (resposta) { return resposta.json(); })
        .then(function (dados) { renderizarTarefas(dados.tarefas); })
        .catch(function () {
            document.getElementById('lista-tarefas').innerHTML = '<p>Erro ao carregar tarefas.</p>';
        });
}

// Carrega todas as tarefas assim que a página abre
document.addEventListener('DOMContentLoaded', function () {
    if (document.getElementById('lista-tarefas')) {
        filtrarTarefas();
    }
});